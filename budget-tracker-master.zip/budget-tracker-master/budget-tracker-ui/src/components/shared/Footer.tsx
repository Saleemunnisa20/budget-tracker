// For a file like DeleteAccount.tsx, you can add this:
export {};

// Or if you are importing something
import React from 'react';

// Your component code here
const Footer = () => {
  // Component logic
  return <div>Shared footer</div>;
};

export default Footer;
