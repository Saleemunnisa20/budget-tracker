// For a file like DeleteAccount.tsx, you can add this:
export {};

// Or if you are importing something
import React from 'react';

// Your component code here
const Header = () => {
  // Component logic
  return <div>Shared Header</div>;
};

export default Header;
