// For a file like DeleteAccount.tsx, you can add this:
export {};

// Or if you are importing something
import React from 'react';

// Your component code here
const DeleteAccount = () => {
  // Component logic
  return <div>Delete Account</div>;
};

export default DeleteAccount;
