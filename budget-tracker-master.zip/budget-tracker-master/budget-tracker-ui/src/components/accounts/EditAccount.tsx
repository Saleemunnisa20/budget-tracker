// For a file like DeleteAccount.tsx, you can add this:
export {};

// Or if you are importing something
import React from 'react';

// Your component code here
const EditAccount = () => {
  // Component logic
  return <div>Edit Account</div>;
};

export default EditAccount;
