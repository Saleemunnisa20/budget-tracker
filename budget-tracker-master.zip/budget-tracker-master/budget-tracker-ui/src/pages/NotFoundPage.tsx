// For a file like DeleteAccount.tsx, you can add this:
export {};

// Or if you are importing something
import React from 'react';

// Your component code here
const NotFoundPage = () => {
  // Component logic
  return <div>Not found</div>;
};

export default NotFoundPage;
