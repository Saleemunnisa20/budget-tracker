// For a file like DeleteAccount.tsx, you can add this:
export {};

// Or if you are importing something
import React from 'react';

// Your component code here
const AccountsPage = () => {
  // Component logic
  return <div>Welcome to accounts page</div>;
};

export default AccountsPage;
