package cisc._3.budget_tracker

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class BudgetTrackerApplicationTests {

	@Test
	fun contextLoads() {
	}

}
