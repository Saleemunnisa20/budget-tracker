package cisc._3.budget_tracker.exception

class InsufficientFundsException(override val message: String) : Exception()