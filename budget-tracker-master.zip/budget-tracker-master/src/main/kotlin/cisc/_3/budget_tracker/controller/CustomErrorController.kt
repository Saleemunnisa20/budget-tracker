package cisc._3.budget_tracker.controller

class CustomErrorController {
}