package cisc._3.budget_tracker.model

data class ErrorMessage(
    val errorCode: Int,
    val errorMessage: String
)
