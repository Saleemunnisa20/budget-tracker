package cisc._3.budget_tracker.exception

class AccountNotFoundException(override val message: String) : Exception()